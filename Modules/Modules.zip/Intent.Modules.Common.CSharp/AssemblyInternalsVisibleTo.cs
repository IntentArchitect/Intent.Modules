﻿[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Intent.Modules.Common.CSharp.Tests")]

﻿namespace Intent.Modules.Common.Templates
{
    public interface IRoslynMerge
    {
        RoslynMergeConfig ConfigureRoslynMerger();
    }
}

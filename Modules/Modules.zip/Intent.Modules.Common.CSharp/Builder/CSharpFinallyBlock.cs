﻿namespace Intent.Modules.Common.CSharp.Builder;

public class CSharpFinallyBlock : CSharpStatementBlock
{
    public CSharpFinallyBlock() : base($"finally")
    {
    }
}
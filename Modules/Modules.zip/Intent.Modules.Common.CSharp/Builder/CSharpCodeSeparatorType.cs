namespace Intent.Modules.Common.CSharp.Builder;

public enum CSharpCodeSeparatorType
{
    None = 0,
    NewLine = 1,
    EmptyLines = 2
}
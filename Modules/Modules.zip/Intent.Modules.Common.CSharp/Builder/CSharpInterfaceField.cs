namespace Intent.Modules.Common.CSharp.Builder;

public class CSharpInterfaceField : CSharpField
{
    public CSharpInterfaceField(string type, string name) : base(type, name)
    {
    }
}